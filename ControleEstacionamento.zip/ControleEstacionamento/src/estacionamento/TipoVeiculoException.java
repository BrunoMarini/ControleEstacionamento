package estacionamento;

public class TipoVeiculoException extends Exception {

	public TipoVeiculoException() {
		// TODO Auto-generated constructor stub
	}

}
