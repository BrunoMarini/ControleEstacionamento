package estacionamento;

public class VagaLotadaException extends Exception{

	public VagaLotadaException() {
		// TODO Auto-generated constructor stub
	}

}
