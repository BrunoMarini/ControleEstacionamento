package estacionamento;

public class VeiculoNaoEncontradoException extends Exception{

	public VeiculoNaoEncontradoException() {
		// TODO Auto-generated constructor stub
	}

}
